<?php


namespace app\modules\v1\factory\goods;


use app\modules\v1\factory\BaseFactory;

class DetailFactory extends BaseFactory
{
    public $form_map = [

    ];

}