<?php

namespace app\modules\v1\forms\admin\menugroup;



use app\componments\sql\SqlUpdate;
use app\modules\v1\forms\CommonForm;


class UpdateForm extends CommonForm
{


   public $menu_id;
	public $group_id;
	public $is_enable;
	


    public function addRule(){
       return [
           [["menu_id","group_id","is_enable"],'required','message'=>'{attribute}不能为空'],
           [['menu_id'], 'exist','targetClass' => 'app\models\admin\menugroup', 'message' => '{attribute}不存在'],

       ];
    }

    public function run($form){

        $obj=new SqlUpdate();
        $obj->setTableName('admin_menugroup');
        $obj->setData($form);
        $obj->setWhere(['menu_id='=>$form->menu_id]);
        return $obj->run();

    }
}