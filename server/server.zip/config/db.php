<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=47.92.6.86;dbname=ybjc',
    'username' => 'user',
    'password' => 'storecode8888',
    'charset' => 'utf8',
    'tablePrefix'=>'ssc_',
    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
