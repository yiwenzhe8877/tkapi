<?php

namespace app\models\apitest;


class usercase extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_apitest_usercase';
    }

}
