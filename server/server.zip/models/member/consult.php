<?php

namespace app\models\member;


class consult extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_member_consult';
    }

}
