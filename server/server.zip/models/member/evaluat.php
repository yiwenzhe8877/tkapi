<?php

namespace app\models\member;


class evaluat extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_member_evaluat';
    }

}
