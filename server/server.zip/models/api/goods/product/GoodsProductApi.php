<?php


namespace app\models\api\goods\product;


use app\componments\utils\Assert;


class GoodsProductApi
{

}