<?php


namespace app\models\api\goods\goods;


use app\componments\utils\Assert;


class GoodsGoodsApi
{

}