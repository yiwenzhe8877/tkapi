<?php


namespace app\models\api\goods\logs;


use app\componments\utils\Assert;


class GoodsLogsApi
{

}