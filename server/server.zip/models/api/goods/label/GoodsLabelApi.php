<?php


namespace app\models\api\goods\label;


use app\componments\utils\Assert;


class GoodsLabelApi
{

}