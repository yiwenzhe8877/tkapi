<?php


namespace app\models\api\goods\models;


use app\componments\utils\Assert;


class GoodsModelsApi
{

}