<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18
 * Time: 11:06
 */
namespace app\models\api\admin\group;

use app\componments\sql\SqlUpdate;
use app\componments\utils\Assert;

class ForbidAdminGroupApi
{
    public static function forbid($group_id){



    }

}