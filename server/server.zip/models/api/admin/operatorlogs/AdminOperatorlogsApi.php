<?php


namespace app\models\api\admin\operatorlogs;


use app\componments\utils\Assert;


class AdminOperatorlogsApi
{

}