<?php


namespace app\models\api\admin\groupauth;


use app\componments\utils\Assert;


class AdminGroupauthApi
{

}