<?php


namespace app\models\api\admin\menu;


use app\componments\utils\Assert;


class AdminMenuApi
{

}