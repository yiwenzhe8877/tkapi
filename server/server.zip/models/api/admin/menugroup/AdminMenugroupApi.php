<?php


namespace app\models\api\admin\menugroup;


use app\componments\utils\Assert;


class AdminMenugroupApi
{

}