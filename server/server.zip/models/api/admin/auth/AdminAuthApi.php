<?php


namespace app\models\api\admin\auth;


use app\componments\utils\Assert;


class AdminAuthApi
{

}