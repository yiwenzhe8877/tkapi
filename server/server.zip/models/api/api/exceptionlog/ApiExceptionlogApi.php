<?php


namespace app\models\api\api\exceptionlog;


use app\componments\utils\Assert;


class ApiExceptionlogApi
{

}