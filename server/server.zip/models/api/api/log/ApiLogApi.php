<?php


namespace app\models\api\api\log;


use app\componments\utils\Assert;


class ApiLogApi
{

}