<?php
namespace app\models\api\statistics;


class StatisticsApi
{

    public static function getOrderNum(){

    }
}