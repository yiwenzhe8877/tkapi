<?php


namespace app\models\api\freight\template;


use app\componments\utils\Assert;


class FreightTemplateApi
{

}