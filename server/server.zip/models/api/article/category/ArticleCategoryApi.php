<?php


namespace app\models\api\article\category;


use app\componments\utils\Assert;


class ArticleCategoryApi
{

}