<?php


namespace app\models\api\article\article;


use app\componments\utils\Assert;


class ArticleArticleApi
{

}