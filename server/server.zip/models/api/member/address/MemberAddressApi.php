<?php


namespace app\models\api\member\address;


use app\componments\utils\Assert;


class MemberAddressApi
{

}