<?php


namespace app\models\api\member\loginlog;


use app\componments\utils\Assert;


class MemberLoginlogApi
{

}