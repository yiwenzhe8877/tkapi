<?php


namespace app\models\api\member\cart;


use app\componments\utils\Assert;


class MemberCartApi
{

}