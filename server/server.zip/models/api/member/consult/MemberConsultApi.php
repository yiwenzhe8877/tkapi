<?php


namespace app\models\api\member\consult;


use app\componments\utils\Assert;


class MemberConsultApi
{

}