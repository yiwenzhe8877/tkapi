<?php


namespace app\models\api\member\money;


use app\componments\utils\Assert;


class MemberMoneyApi
{

}