<?php


namespace app\models\api\member\sysmsg;


use app\componments\utils\Assert;


class MemberSysmsgApi
{

}