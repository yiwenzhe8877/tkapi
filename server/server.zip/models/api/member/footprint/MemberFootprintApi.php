<?php


namespace app\models\api\member\footprint;


use app\componments\utils\Assert;


class MemberFootprintApi
{

}