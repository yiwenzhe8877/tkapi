<?php


namespace app\models\api\member\profile;


use app\componments\utils\Assert;


class MemberProfileApi
{

}