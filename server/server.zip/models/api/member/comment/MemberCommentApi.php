<?php


namespace app\models\api\member\comment;


use app\componments\utils\Assert;


class MemberCommentApi
{

}