<?php


namespace app\models\api\member\verify;


use app\componments\utils\Assert;


class MemberVerifyApi
{

}