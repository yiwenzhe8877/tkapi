<?php


namespace app\models\api\member\evaluat;


use app\componments\utils\Assert;


class MemberEvaluatApi
{

}