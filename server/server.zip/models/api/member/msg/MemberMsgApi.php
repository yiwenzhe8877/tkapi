<?php


namespace app\models\api\member\msg;


use app\componments\utils\Assert;


class MemberMsgApi
{

}