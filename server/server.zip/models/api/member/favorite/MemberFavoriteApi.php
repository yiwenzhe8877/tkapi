<?php


namespace app\models\api\member\favorite;


use app\componments\utils\Assert;


class MemberFavoriteApi
{

}