<?php


namespace app\models\api\member\point;


use app\componments\utils\Assert;


class MemberPointApi
{

}