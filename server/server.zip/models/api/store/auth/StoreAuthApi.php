<?php


namespace app\models\api\store\auth;


use app\componments\utils\Assert;


class StoreAuthApi
{

}