<?php


namespace app\models\api\store\menugroup;


use app\componments\utils\Assert;


class StoreMenugroupApi
{

}