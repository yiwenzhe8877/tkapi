<?php


namespace app\models\api\store\operatorlogs;


use app\componments\utils\Assert;


class StoreOperatorlogsApi
{

}