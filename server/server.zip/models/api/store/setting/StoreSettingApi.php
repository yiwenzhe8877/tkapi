<?php


namespace app\models\api\store\setting;


use app\componments\utils\Assert;


class StoreSettingApi
{

}