<?php


namespace app\models\api\store\groupauth;


use app\componments\utils\Assert;


class StoreGroupauthApi
{

}