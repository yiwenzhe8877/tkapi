<?php

namespace app\models\store;


class setting extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_store_setting';
    }

}
