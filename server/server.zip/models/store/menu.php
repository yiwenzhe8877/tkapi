<?php

namespace app\models\store;


class menu extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_store_menu';
    }

}
