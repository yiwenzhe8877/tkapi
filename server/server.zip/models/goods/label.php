<?php

namespace app\models\goods;


class label extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_goods_label';
    }

}
