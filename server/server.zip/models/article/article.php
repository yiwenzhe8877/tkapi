<?php

namespace app\models\article;


class article extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'ssc_article';
    }

}
