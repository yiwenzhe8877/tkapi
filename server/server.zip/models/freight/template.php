<?php

namespace app\models\freight;


class template extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tk_freight_template';
    }

}
