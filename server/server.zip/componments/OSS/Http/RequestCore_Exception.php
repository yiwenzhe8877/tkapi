<?php

namespace app\componments\OSS\Http;

class RequestCore_Exception extends \Exception
{

}