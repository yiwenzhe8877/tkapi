<?php
/**
 * Created by PhpStorm.
 * User: idz025
 * Date: 2018/12/24
 * Time: 15:41
 */

namespace app\componments\utils;


class VerifyCode
{

}